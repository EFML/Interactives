def test_hello(expect, ans):
    return expect == ans.lower()
