def dist1D(xf,xi):
    #print xf,xi,xf-xi
    return xf-xi
    